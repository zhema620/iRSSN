function [] = extract_ROI_mat(atlas,datapath)

% -------------------------------------------------------------------------
% DESCRIPTION:
% This function extracts extracts ROI atlas information and saved in each 
% subject folder
% -------------------------------------------------------------------------

k = max(max(max(atlas)));
for i=1:k
    mask=double(atlas==i);
    roi_file(:,:,:,i)=mask;
end
roi_file(find(roi_file>1))=1;
save('ROI_4D.mat','roi_file');
data=dir(datapath);
for j=3:size(data,1)
    copyfile('ROI_4D.mat',strcat(datapath,'\',data(j).name))
end
end
