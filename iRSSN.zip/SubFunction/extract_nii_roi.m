function [] = extract_nii_roi(images, datapath)

% -------------------------------------------------------------------------
% DESCRIPTION:
% This function extracts sMRI images matrix information of each subjects,
% and saved in each subject folder
% -------------------------------------------------------------------------
for i=1:size(images,1)
    nii=load_nii(images(i).fname);
    result=nii.img;
    save('sMRI.mat','result');
    fold=images(i).fname;
    mkdir(strcat(datapath,'\',fold(end-10:end-4)));
    movefile('sMRI.mat',strcat(datapath,'\',fold(end-10:end-4)));
end
end