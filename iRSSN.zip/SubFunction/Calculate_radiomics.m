function Calculate_radiomics(datapath, savepath)

% -------------------------------------------------------------------------
% DESCRIPTION:
% This function extracts texture features from sMRI data based specific
% atlas, and calculates individualized structural similarity network 
% -------------------------------------------------------------------------

subject = dir(datapath);
radiomics=[];
for i=3:size(subject,1)
cd(strcat(subject(i).folder,'\',subject(i).name));
load('sMRI.mat');
load('ROI_4D.mat');
for j=1:size(roi_file,4)
index=1;
[ROIonly,levels] = prepareVolume(result,roi_file(:,:,:,j),'MRscan',1.5,1.5,1,1.5,'Matrix','Lloyd',32);
glcm_mat=getGLCM(ROIonly,levels);
glcm_texture=getGLCMtextures(glcm_mat);
glcm_name=fieldnames(glcm_texture);
for k=1:size(glcm_name,1)
radiomics(i-2,j,index)=getfield(glcm_texture,glcm_name{k});
index=index+1;
end
glrlm_mat=getGLRLM(ROIonly,levels);
glrlm_texture=getGLRLMtextures(glrlm_mat);
glrlm_name=fieldnames(glrlm_texture);
for l=1:size(glrlm_name,1)
radiomics(i-2,j,index)=getfield(glrlm_texture,glrlm_name{l});
index=index+1;
end
glszm_mat=getGLSZM(ROIonly,levels);
glszm_texture=getGLSZMtextures(glszm_mat);
glszm_name=fieldnames(glszm_texture);
for m=1:size(glszm_name,1)
radiomics(i-2,j,index)=getfield(glszm_texture,glszm_name{m});
index=index+1;
end
[ngtdm_mat,countvalid]=getNGTDM(ROIonly,levels);
ngtdm_texture=getNGTDMtextures(ngtdm_mat,countvalid);
ngtdm_name=fieldnames(ngtdm_texture);
for n=1:size(ngtdm_name,1)
radiomics(i-2,j,index)=getfield(ngtdm_texture,ngtdm_name{n});
index=index+1;
end
[ROIonly_glo] = prepareVolume(result,roi_file(:,:,:,j),'MRscan',1.5,1.5,2,1.5,'Global');
global_texture=getGlobalTextures(ROIonly_glo,32);
global_name=fieldnames(global_texture);
for h=1:size(global_name,1)
radiomics(i-2,j,index)=getfield(global_texture,global_name{h});
index=index+1;
end
end
end

% calculate the individual radiomics connectome
[x,y,z]=size(radiomics); 
mradiomics=zeros(x,y,z);
for mi=1:x
mradiomics(mi,:,:)=radiomics(mi,:,:)./mean(radiomics(mi,:,:),2);
end

for xi=1:x
    for yi=1:y
        for zi=1:y
     [fc(yi,zi),pvalue(yi,zi)]=corr(squeeze(mradiomics(xi,yi,:)),squeeze(mradiomics(xi,zi,:)));
        end
    end
    
    save(strcat(savepath,'\iRSSN_',subject(xi+2).name,'.txt'),'fc','-ascii');
    save(strcat(savepath,'\P_',subject(xi+2).name,'.txt'),'pvalue','-ascii');
end
cd(savepath)
end
